package com.example.rakathon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

public class ResultActivity extends AppCompatActivity {
    TextView qN;
    final Context context = this;

Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String flag = getIntent().getStringExtra("flag");
        String conditionName= getIntent().getStringExtra("conditionName");
        Double fraction = getIntent().getDoubleExtra("fraction", 0.0);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.result);
        writeLevel(fraction,flag,conditionName);
        addListenerOnButton(conditionName);
    }
        public void addListenerOnButton(final String conditionName) {

        button = (Button) findViewById(R.id.anotherTest);
        button.setOnClickListener(new OnClickListener() {
        @Override
        public void onClick(View arg0) {
            Intent intent = new Intent(context, MainActivity.class);
            startActivity(intent);
        }
    });
        button = (Button) findViewById(R.id.seeHistory);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(context, HistoryActivity.class);
                intent.putExtra("conditionName",conditionName);
                startActivity(intent);
            }
        });
//        button = (Button) findViewById(R.id.exit);
//        button.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                finish();
//                System.exit(0);
//            }
//        });


        ///////////////////


}
    private void writeLevel(double fractionLevel,final String flag,final String conditionName){
        qN = findViewById(R.id.level);
        if(fractionLevel==1.0)
            qN.setText("Your results indicate that you may be at: Level 4"+ " by " + flag+" of suffering from "+conditionName+" Scores in this range are indicative of "+conditionName+". Based on your answers, living with these symptoms is likely to be causing many problems in your day-to-day life.");
        else if(fractionLevel>=0.75&&fractionLevel<1.0)
            qN.setText("Your results indicate that you may be at: Level 3"+ " by " + flag+" of suffering from "+conditionName+" Scores in this range are indicative of "+conditionName+". Based on your answers, living with these symptoms is likely to be causing many problems in your day-to-day life.");
        else if(fractionLevel>=0.50&&fractionLevel<0.75)
            qN.setText("Your results indicate that you may be at: Level 2"+ " by " + flag+" of suffering from "+conditionName+" Scores in this range are indicative of "+conditionName+". Based on your answers, living with these symptoms is likely to be causing many problems in your day-to-day life.");
        else if(fractionLevel>=0.25&&fractionLevel<0.50)
            qN.setText("Your results indicate that you may be at: Level 1"+ " by " + flag+" of suffering from "+conditionName+" Scores in this range are indicative of "+conditionName+". Based on your answers, living with these symptoms is likely to be causing many problems in your day-to-day life.");
        else if(fractionLevel<0.25)
            qN.setText("Your results indicate that you may be at: Level 0"+ " by " + flag+" of suffering from "+conditionName+" Scores in this range are indicative of "+conditionName+". Based on your answers, living with these symptoms is likely to be causing many problems in your day-to-day life.");
    }




}