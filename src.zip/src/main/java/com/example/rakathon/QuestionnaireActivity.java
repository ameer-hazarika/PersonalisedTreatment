package com.example.rakathon;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import com.opencsv.CSVWriter;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static android.provider.Telephony.Mms.Part.FILENAME;
import static androidx.constraintlayout.widget.ConstraintSet.*;
import static androidx.constraintlayout.widget.ConstraintSet.BOTTOM;

public class QuestionnaireActivity extends AppCompatActivity {
    TextView qN;
    TextView qs;
    CSVWriter writer;
    Calendar calendar;
    DateFormat dateFormat;
    String date;

    static int counter = 1;
    Button button;
    static double point=0;
    static double total =0;
    static double fraction=0.0;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        String[] HeadingArray=getIntent().getStringArrayExtra("HeadingArray");
        String conditionName= getIntent().getStringExtra("conditionName");
        String flag=getIntent().getStringExtra("flag");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.questionnaire);


        addListenerOnButton(HeadingArray,flag,conditionName);
        dynamicValues(HeadingArray);
    }
    public void addListenerOnButton(final String [] HeadingArray,final String flag,final String conditionName) {


        final Context context = this;
        button = (Button) findViewById(R.id.next);
        final RadioGroup rgb = findViewById(R.id.AnswerGroup);

        button.setOnClickListener(new View.OnClickListener() {
            RadioButton selectedRadioButton;
            @Override
            public void onClick(View arg0) {
                if (!(rgb.getCheckedRadioButtonId() == -1)){
                    int selectedId = rgb.getCheckedRadioButtonId();
                    // find the radiobutton by returned id
                    selectedRadioButton = (RadioButton)findViewById(selectedId);
                    if(selectedRadioButton.getText().toString().equalsIgnoreCase("never")){
                        point+= 0;
                    }
                    else if(selectedRadioButton.getText().toString().equalsIgnoreCase("sometimes")){
                        point+= 1;
                    }
                    else if(selectedRadioButton.getText().toString().equalsIgnoreCase("most times")){
                        point+= 2;
                    }
                    else if(selectedRadioButton.getText().toString().equalsIgnoreCase("always")){
                        point+= 3;
                    }


                    Toast.makeText(getApplicationContext(), selectedRadioButton.getText().toString()+" is selected ", Toast.LENGTH_LONG).show();
                    if(counter!= HeadingArray.length+1)
                        dynamicValues(HeadingArray);
                    else
                    {
                        counter = 1;
                        total=3*HeadingArray.length;
                        fraction=point/total;
                        String csv;
                        String filePath;
                        if(flag.equalsIgnoreCase("self")) {
                             csv = "test1.txt";
                             filePath = context.getFilesDir().getPath().toString() + "/test1.txt";
                        }else{
                             csv = "test2.txt";
                             filePath = context.getFilesDir().getPath().toString() + "/test2.txt";
                        }
                        FileOutputStream fos=null;
                        OutputStreamWriter outputStreamWriter=null;
                        try {
                            outputStreamWriter = new OutputStreamWriter(context.openFileOutput(csv, Context.MODE_PRIVATE));

                            // fos = openFileOutput(csv, Context.MODE_PRIVATE);
                            writer = new CSVWriter(new FileWriter(filePath));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        calendar = Calendar.getInstance();
                        dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                        date = dateFormat.format(calendar.getTime()).toString();
                        String[] writeRow={date,Double.toString(fraction)};
                        try {
                            outputStreamWriter.write(date);
                            outputStreamWriter.write(Double.toString(fraction));
//                            fos.write(Double.toString(fraction).getBytes());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        writer.writeNext(writeRow);


                        try {
                            writer.close();
//                            fos.close();
                            outputStreamWriter.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            System.out.println(e);
                            String test = e.getMessage();
                        }
                        point=0;total =0;
                        Intent intent = new Intent(context,ResultActivity.class);
                        intent.putExtra("fraction",fraction);
                        intent.putExtra("conditionName",conditionName);
                        intent.putExtra("flag",flag);
                        startActivity(intent);
                    }
                    rgb.clearCheck();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Please select one of the options", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void dynamicValues(final String [] HeadingArray){
        qN = findViewById(R.id.questionNumber);
        qN.setText(counter +" of "+HeadingArray.length);
        qs = findViewById(R.id.question);
        qs.setText(HeadingArray[counter-1]);
        counter ++;
    }
}
