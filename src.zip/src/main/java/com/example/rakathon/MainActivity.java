package com.example.rakathon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    TextView textViewDepression;
    ImageView imageViewDepression;
    TextView textViewADHD;
    ImageView imageViewADHD;
    TextView textViewAnxiety;
    ImageView imageViewAnxiety;
    TextView textViewBipolar;
    ImageView imageViewBipolar;
    TextView textViewPTSD;
    ImageView imageViewPTSD;
    TextView textViewPsychosis;
    ImageView imageViewPsychosis;

    String[] array={"This test consists of a series of 2 questions which can help in analysing the level of depression you may be suffering from",
        "This test consists of a series of 3 questions which can help in analysing the level of ADHD you may be suffering from",
        "This test consists of a series of 2 questions which can help in analysing the level of Anxiety you may be suffering from",
        "This test consists of a series of 4 questions which can help in analysing the level of Bipolar disorder you may be suffering from",
        "This test consists of a series of 2 questions which can help in analysing the level of PTSD you may be suffering from",
        "This test consists of a series of 8 questions which can help in analysing the level of Psychosis you may be suffering from"};

    String[] array2={"DEPRESSION","ADHD","ANXIETY","BIPOLAR DISORDER","PTSD","PSYCHOSIS"};

    String[] QuestionArrayDepression = {"Are you having difficulty in focusing ?", "Are you feeling lethargic ?"};
    String[] QuestionArrayADHD = {"Question1 ADHD", "Question2 ADHD","Question3 ADHD"};
    String[] QuestionArrayAnxiety = {"Question1 Anxiety", "Question2 Anxiety"};
    String[] QuestionArrayBipolar = {"Question1 Bipolar disorder", "Question2 Bipolar disorder","Question3 Bipolar disorder","Question4 Bipolar disorder"};
    String[] QuestionArrayPTSD = {"Question1 PTSD", "Question2 PTSD"};
    String[] QuestionArrayPsychosis = {"Question1 Psychosis", "Question2 Psychosis","Question3 Psychosis","Question4 Psychosis"
            ,"Question5 Psychosis", "Question6 Psychosis","Question7 Psychosis","Question8 Psychosis"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnTextView();
    }
    public void addListenerOnTextView() {

        final Context context = this;

        textViewDepression = findViewById(R.id.depressionText);
        imageViewDepression=findViewById(R.id.Depression);
        textViewADHD = findViewById(R.id.adhdText);
        imageViewADHD=findViewById(R.id.ADHD);
        textViewAnxiety = findViewById(R.id.anxietyText);
        imageViewAnxiety=findViewById(R.id.Anxiety);
        textViewBipolar = findViewById(R.id.bipolar);
        imageViewBipolar=findViewById(R.id.Bipolar);
        textViewPTSD = findViewById(R.id.ptsdText);
        imageViewPTSD=findViewById(R.id.PTSD);
        textViewPsychosis = findViewById(R.id.psychosisText);
        imageViewPsychosis=findViewById(R.id.Psychosis);

        textViewDepression.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
//                Intent intentQuestion = new Intent(context, QuestionnaireActivity.class);
//                intentQuestion.putExtra("HeadingArray",QuestionArrayDepression);
                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[0]);
                intent.putExtra("Heading",array2[0]);
                intent.putExtra("HeadingArray",QuestionArrayDepression);
                startActivity(intent);
            }

        });
        imageViewDepression.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
//                Intent intentQuestion = new Intent(context, QuestionnaireActivity.class);
//                intentQuestion.putExtra("HeadingArray",QuestionArrayDepression);
                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[0]);
                intent.putExtra("Heading",array2[0]);
                intent.putExtra("HeadingArray",QuestionArrayDepression);
                startActivity(intent);

            }

        });

        textViewADHD.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[1]);
                intent.putExtra("Heading",array2[1]);
                intent.putExtra("HeadingArray",QuestionArrayADHD);
                startActivity(intent);

            }

        });
        imageViewADHD.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[1]);
                intent.putExtra("Heading",array2[1]);
                intent.putExtra("HeadingArray",QuestionArrayADHD);
                startActivity(intent);

            }

        });

        textViewAnxiety.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[2]);
                intent.putExtra("Heading",array2[2]);
                intent.putExtra("HeadingArray",QuestionArrayAnxiety);
                startActivity(intent);

            }

        });
        imageViewAnxiety.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[2]);
                intent.putExtra("Heading",array2[2]);
                intent.putExtra("HeadingArray",QuestionArrayAnxiety);
                startActivity(intent);

            }

        });

        textViewBipolar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[3]);
                intent.putExtra("Heading",array2[3]);
                intent.putExtra("HeadingArray",QuestionArrayBipolar);
                startActivity(intent);

            }

        });
        imageViewBipolar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[3]);
                intent.putExtra("Heading",array2[3]);
                intent.putExtra("HeadingArray",QuestionArrayBipolar);
                startActivity(intent);

            }

        });

        textViewPTSD.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[4]);
                intent.putExtra("Heading",array2[4]);
                intent.putExtra("HeadingArray",QuestionArrayPTSD);
                startActivity(intent);

            }

        });
        imageViewPTSD.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[4]);
                intent.putExtra("Heading",array2[4]);
                intent.putExtra("HeadingArray",QuestionArrayPTSD);
                startActivity(intent);

            }

        });

        textViewPsychosis.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[5]);
                intent.putExtra("Heading",array2[5]);
                intent.putExtra("HeadingArray",QuestionArrayPsychosis);
                startActivity(intent);

            }

        });
        imageViewPsychosis.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, ScreenOneActivity.class);
                intent.putExtra("condition",array[5]);
                intent.putExtra("Heading",array2[5]);
                intent.putExtra("HeadingArray",QuestionArrayPsychosis);
                startActivity(intent);

            }

        });
    }
}