package com.example.rakathon;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

public class HistoryActivity extends AppCompatActivity {

    LineGraphSeries<DataPoint> series;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String flag = getIntent().getStringExtra("flag");
        String conditionName= getIntent().getStringExtra("conditionName");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history);
        readCsvSelf(conditionName);
        readCsvConfidant(conditionName);
    }

    private void readCsvSelf(final String conditionName) {
        // Read the raw csv file
        InputStream is;
            is = getResources().openRawResource(R.raw.test1);


        // Reads text from character-input stream, buffering characters for efficient reading
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );

        // Initialization
        String line = "";

        // Initialization
        try {
            // Step over headers
            reader.readLine();

            // If buffer is not empty
            while ((line = reader.readLine()) != null) {
                Log.d("MyActivity","Line: " + line);
                // use comma as separator columns of CSV
                String[] tokens = line.split(",");
                double x, y;
                x=Double.parseDouble(tokens[0]);
                GraphView graphView =(GraphView) findViewById(R.id.graphView);
                graphView.setTitle(conditionName +"\n Self");
                graphView.getGridLabelRenderer().setVerticalAxisTitle("Level");
                graphView.getGridLabelRenderer().setHorizontalAxisTitle("Date");
                series=new LineGraphSeries<DataPoint>();
                for(int i=0;i<100;i++){
                    x+=0.1;
                    y=5*x;
                    series.appendData(new DataPoint(x,y),true,100);

                }
                graphView.addSeries(series);
                // Read the data
            }

        } catch (IOException e) {
            // Logs error with priority level
            Log.wtf("MyActivity", "Error reading data file on line" + line, e);

            // Prints throwable details
            e.printStackTrace();
        }
    }
    private void readCsvConfidant(final String conditionName) {
        // Read the raw csv file
        InputStream is;
        is = getResources().openRawResource(R.raw.test1);


        // Reads text from character-input stream, buffering characters for efficient reading
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );

        // Initialization
        String line = "";

        // Initialization
        try {
            // Step over headers
            reader.readLine();

            // If buffer is not empty
            while ((line = reader.readLine()) != null) {
                Log.d("MyActivity","Line: " + line);
                // use comma as separator columns of CSV
                String[] tokens = line.split(",");
                double x, y;
                x=Double.parseDouble(tokens[0]);
                GraphView graphView =(GraphView) findViewById(R.id.graphView2);
                graphView.setTitle(conditionName+"\n Confidants");
                graphView.getGridLabelRenderer().setVerticalAxisTitle("Level");
                graphView.getGridLabelRenderer().setHorizontalAxisTitle("Date");
                series=new LineGraphSeries<DataPoint>();
                for(int i=0;i<100;i++){
                    x+=0.1;
                    y=5*x;
                    series.appendData(new DataPoint(x,y),true,100);

                }
                graphView.addSeries(series);
                // Read the data
            }

        } catch (IOException e) {
            // Logs error with priority level
            Log.wtf("MyActivity", "Error reading data file on line" + line, e);

            // Prints throwable details
            e.printStackTrace();
        }
    }
}