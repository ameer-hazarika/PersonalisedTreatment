package com.example.rakathon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DisclaimerActivity extends AppCompatActivity {
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String[] HeadingArray=getIntent().getStringArrayExtra("HeadingArray");
        String conditionName= getIntent().getStringExtra("conditionName");
        String flag=getIntent().getStringExtra("flag");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.disclaimer);
        addListenerOnTextView(HeadingArray,flag,conditionName);

    }


    public void addListenerOnTextView(final String[] HeadingArray, final String flag,final String conditionName) {

        final Context context = this;

        button = findViewById(R.id.iAccept);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, QuestionnaireActivity.class);
                intent.putExtra("HeadingArray",HeadingArray);
                intent.putExtra("conditionName",conditionName);
                intent.putExtra("flag",flag);
                startActivity(intent);

            }

        });


    }
}