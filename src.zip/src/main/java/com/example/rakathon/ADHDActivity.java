package com.example.rakathon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ADHDActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.disclaimer);
    }



}