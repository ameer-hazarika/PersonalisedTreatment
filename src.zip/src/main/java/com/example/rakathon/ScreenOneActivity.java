package com.example.rakathon;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ScreenOneActivity extends AppCompatActivity {
    Button startButton,seeHistoryButton;
    TextView screenText;




//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String[] HeadingArray=getIntent().getStringArrayExtra("HeadingArray");
        String screenOneText = getIntent().getStringExtra("condition");
        String screenOneHeading = getIntent().getStringExtra("Heading");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_one);
        screenText= findViewById(R.id.screenOneHead);
        screenText.setText(screenOneHeading);
        screenText= findViewById(R.id.screenOneText);
        screenText.setText(screenOneText);

       // setContentView(R.layout.screen_one);
        addListenerOnButton(HeadingArray,screenOneHeading);
    }

    public void addListenerOnButton(final String [] HeadingArray,final String screenOneHeading) {

        final Context context = this;

        startButton = (Button) findViewById(R.id.startButton);
        seeHistoryButton = (Button) findViewById(R.id.see_history);

        startButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, TestTakerActivity.class);
                intent.putExtra("HeadingArray",HeadingArray);
                intent.putExtra("conditionName",screenOneHeading);
                startActivity(intent);

            }

        });
        seeHistoryButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, HistoryActivity.class);
                intent.putExtra("conditionName",screenOneHeading);
                startActivity(intent);

            }

        });


    }



}