package com.example.rakathon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TestTakerActivity extends AppCompatActivity {
    Button buttonSelf;
    Button buttonOther;
    String flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String[] HeadingArray=getIntent().getStringArrayExtra("HeadingArray");
         String conditionName= getIntent().getStringExtra("conditionName");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.testtaker);
        addListenerOnButton(HeadingArray,conditionName);

    }

    public void addListenerOnButton(final String[] HeadingArray,final String conditionName) {
        //SQLiteDatabase mydatabase = openOrCreateDatabase("your database name",MODE_PRIVATE,null);

        final Context context = this;

        buttonSelf = (Button) findViewById(R.id.self);
        buttonOther = (Button) findViewById(R.id.others);

        buttonSelf.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                flag="Self";
                Intent intent = new Intent(context, DisclaimerActivity.class);
                intent.putExtra("HeadingArray",HeadingArray);
                intent.putExtra("conditionName",conditionName);
                intent.putExtra("flag",flag);
                startActivity(intent);

            }

        });


        buttonOther.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                flag="Confidants";
                Intent intent = new Intent(context, DisclaimerActivity.class);
                intent.putExtra("HeadingArray",HeadingArray);
                intent.putExtra("conditionName",conditionName);
                intent.putExtra("flag",flag);
                startActivity(intent);

            }

        });

    }



}